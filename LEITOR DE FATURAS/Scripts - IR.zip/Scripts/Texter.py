# ============================================================== #
#     BIBLIOTECAS
# ============================================================== #

import sys
from pathlib import Path
from openpyxl import Workbook

from texter_utils import salvar_arquivo, carregar_arquivo, aba_info_geral, aba_historico_consumo, historico
from Texter_format_functions.texter_format_enel import format_enel
from Texter_format_functions.texter_format_energisa import format_energisa
from Texter_format_functions.texter_format_neoenergia import format_neoenergia

# ============================================================== #
# CONFIGURACOES
# ============================================================== #

if getattr(sys, "frozen", False):
    diretorio = Path(sys.executable).resolve().parent
else:
    diretorio = Path(__file__).resolve().parent.parent

PATH_INPUT = diretorio / "Faturas_Poppler"
PATH_OUTPUT = diretorio / "Faturas_Texter"
PATH_ANALISE = diretorio / "Faturas_Analaiser"

# ============================================================== #
# MAPEAMENTO DAS FUNCOES DE FORMATACAO
# ============================================================== #

FORMATADORES = {
    # "ENEL": format_enel,
    "ENERGISA": format_energisa,
    "NEOENERGIA": format_neoenergia,
}


# ============================================================== #
# FUNCOES
# ============================================================== #

def limpar_estado_processamento():
    # Evita acumular dados de execucoes anteriores na mesma sessao.
    aba_info_geral.clear()
    aba_historico_consumo.clear()
    historico.clear()


def _montar_nome_saida_texter(nome_entrada):
    nome_saida = nome_entrada.replace("Poppler", "Texter")
    if nome_saida == nome_entrada:
        return nome_entrada.replace(".txt", "_Texter.txt")
    return nome_saida


def _converter_para_texto_saida(conteudo_formatado):
    if isinstance(conteudo_formatado, dict):
        return conteudo_formatado.get("texto", "")
    return str(conteudo_formatado)


def _extrair_indicador_tribf_irrf(conteudo_poppler):
    texto = (conteudo_poppler or "").upper()
    return "PRESENTE" if ("TRIBF-IRRF" in texto or "TIBF-IRRF" in texto) else "AUSENTE"


def _extrair_campos_texter(conteudo_texter):
    campos = {}
    for linha in (conteudo_texter or "").splitlines():
        if "\t" not in linha:
            continue
        chave, valor = linha.split("\t", 1)
        campos[chave.strip().upper()] = valor.strip()
    return campos


def _chave_ordenacao_referencia(referencia):
    ref = (referencia or "").strip().upper()
    meses = {
        "JAN": 1, "FEV": 2, "MAR": 3, "ABR": 4, "MAI": 5, "JUN": 6,
        "JUL": 7, "AGO": 8, "SET": 9, "OUT": 10, "NOV": 11, "DEZ": 12,
    }

    partes = ref.split("/")
    if len(partes) != 2:
        return (9999, 99, ref)

    mes_raw = partes[0].strip()
    ano_raw = partes[1].strip()

    if mes_raw.isdigit():
        mes = int(mes_raw)
    else:
        mes = meses.get(mes_raw[:3], 99)

    if ano_raw.isdigit():
        ano = int(ano_raw)
        if ano < 100:
            ano += 2000
    else:
        ano = 9999

    return (ano, mes, ref)


def _gerar_planilha_analise_tribf_irrf(dst_dir):
    arquivos_texter = sorted([f for f in dst_dir.iterdir() if f.is_file() and f.suffix.lower() == ".txt"])
    mapa = {}
    ucs = set()
    referencias = set()

    for arquivo in arquivos_texter:
        campos = _extrair_campos_texter(carregar_arquivo(arquivo))

        uc = campos.get("UNIDADE CONSUMIDORA", "UNK")
        referencia = campos.get("MES/ANO REFERENCIA", "UNK")
        indicador = campos.get("INDICADOR TRIBF-IRRF", "AUSENTE").upper()

        if not uc:
            uc = "UNK"
        if not referencia:
            referencia = "UNK"

        ucs.add(uc)
        referencias.add(referencia)

        chave = (uc, referencia)
        valor_atual = mapa.get(chave)
        if valor_atual == "PRESENTE" or indicador == "PRESENTE":
            mapa[chave] = "PRESENTE"
        else:
            mapa[chave] = "AUSENTE"

    ucs_ordenadas = sorted(ucs)
    referencias_ordenadas = sorted(referencias, key=_chave_ordenacao_referencia)

    PATH_ANALISE.mkdir(parents=True, exist_ok=True)
    nome_planilha = f"{dst_dir.name.replace('Texter', 'Analaiser')}.xlsx"
    caminho_planilha = PATH_ANALISE / nome_planilha

    wb = Workbook()
    ws = wb.active
    ws.title = "TRIBF-IRRF"

    ws.cell(row=1, column=1, value="UNIDADE CONSUMIDORA")
    for col, referencia in enumerate(referencias_ordenadas, start=2):
        ws.cell(row=1, column=col, value=referencia)

    for row, uc in enumerate(ucs_ordenadas, start=2):
        ws.cell(row=row, column=1, value=uc)
        for col, referencia in enumerate(referencias_ordenadas, start=2):
            ws.cell(row=row, column=col, value=mapa.get((uc, referencia), "SEM DADO"))

    wb.save(caminho_planilha)
    return caminho_planilha


# ============================================================== #
# ORQUESTRADOR
# ============================================================== #

def texter_orchestrator():
    PATH_OUTPUT.mkdir(parents=True, exist_ok=True)
    limpar_estado_processamento()

    # 1. Selecao de pasta de origem
    subfolders = [f.name for f in PATH_INPUT.iterdir() if f.is_dir()]
    print("\n--- SELECAO DE PASTA (ORIGEM: POPPLER) ---")
    for i, folder in enumerate(subfolders):
        print(f"{i} - {folder}")

    f_choice = int(input("Indice da pasta: "))
    selected_subfolder = subfolders[f_choice]

    src_dir = PATH_INPUT / selected_subfolder
    dst_dir_name = selected_subfolder.replace("Poppler", "Texter")
    dst_dir = PATH_OUTPUT / dst_dir_name
    dst_dir.mkdir(parents=True, exist_ok=True)

    # 2. Selecao de formato
    print("\n--- QUAL FORMATACAO APLICAR? ---")
    formatos = list(FORMATADORES.keys())
    for i, nome in enumerate(formatos):
        print(f"{i} - {nome}")
    fmt_choice = int(input("Indice do formato: "))
    funcao_formatadora = FORMATADORES[formatos[fmt_choice]]

    # 3. Escopo de execucao
    print("\n--- MODO DE EXECUCAO ---")
    print("1 - Todos os documentos da subpasta")
    print("2 - Apenas um documento especifico")
    mode = input("Escolha a opcao: ").strip()

    files = sorted([f.name for f in src_dir.iterdir() if f.is_file() and f.suffix.lower() == ".txt"])

    if mode == "2":
        for i, file_name in enumerate(files):
            print(f"{i} - {file_name}")
        file_choice = int(input("Indice do arquivo: "))
        files = [files[file_choice]]

    # 4. Processamento de arquivos Texter
    for file_name in files:
        input_path = src_dir / file_name
        print(f"Processando: {file_name}...")

        conteudo_bruto = carregar_arquivo(input_path)
        conteudo_formatado = funcao_formatadora(conteudo_bruto, file_name)
        conteudo_saida = _converter_para_texto_saida(conteudo_formatado)
        indicador_tribf_irrf = _extrair_indicador_tribf_irrf(conteudo_bruto)

        if conteudo_saida and not conteudo_saida.endswith("\n"):
            conteudo_saida += "\n"
        conteudo_saida += f"INDICADOR TRIBF-IRRF\t{indicador_tribf_irrf}\n"

        output_name = _montar_nome_saida_texter(file_name)
        output_path = dst_dir / output_name
        salvar_arquivo(output_path, conteudo_saida)
        print(f"[OK] Arquivo Texter criado: {output_path}")

    caminho_planilha = _gerar_planilha_analise_tribf_irrf(dst_dir)
    print(f"[OK] Planilha de analise gerada: {caminho_planilha}")

    print("\nFluxo Texter finalizado.")


if __name__ == "__main__":
    texter_orchestrator()
